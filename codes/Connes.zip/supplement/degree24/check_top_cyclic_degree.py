#!/usr/bin/env python3
"""Protect degree 24 by a positive Tau^4 class at maximal Y-count 16."""
from pathlib import Path
from collections import defaultdict
import json,itertools
ROOT=Path(__file__).resolve().parent
B={(r['coordinate'],r['component']):r for r in json.loads((ROOT/'inputs/channel_assignment.json').read_text())['assignment']}
P=json.loads((ROOT/'independent_literal_polynomial.json').read_text())
def cyclic(w):return min(w[i:]+w[:i] for i in range(len(w)))
def ymax(r):return sum(B[tuple(z)]['word'].count('Y')+1 for z in r['word'])
top=[r for r in P['penalty_P'] if r['weighted_degree']==24];mx=max(map(ymax,top));keep=[r for r in top if ymax(r)==mx]
assert mx==16 and len(keep)==5
assert max(ymax(r) for r in P['P0'] if r['weighted_degree']==24)==12
out=defaultdict(lambda:defaultdict(int))
for r in keep:
 options=[]
 for z in r['word']:
  a=B[tuple(z)];w=a['word'];decoder=[(w,1)] if w==w[::-1] else [(w,1),(w[::-1],-1 if a['parity'] else 1)]
  options.append([(d+e,c*b) for d,c in decoder for e,b in [('XXY',1),('XYX',2),('YXX',1)]])
 for terms in itertools.product(*options):
  w=''.join(a for a,b in terms);c=1
  for a,b in terms:c*=b
  key=cyclic(w),tuple(sorted(tuple(z) for z in r['word']))
  for i,v in enumerate(r['T_coefficients']):out[key][i]+=c*v
target=cyclic('XXYYYY'*4);hits={m:{i:c for i,c in d.items() if c} for (w,m),d in out.items() if w==target and any(d.values())}
assert len(hits)==1
(m,d),=hits.items();assert m==(('Tau','S'),)*4 and all(c>0 for c in d.values())
q=next(r['T_coefficients'] for r in keep if r['word']==[['Tau','S']]*4)
assert [d.get(i,0) for i in range(len(q))]==[2*x for x in q]
# Source symmetrization adds the reverse cyclic coefficient; this class is
# reversal invariant, so the final 800*(C+C*) gives another factor 1600.
assert cyclic(target[::-1])==target
result=dict(status='PASS_EXACT_ORDINARY_AND_CYCLIC_DEGREE_24',cyclic_word=target,Y_count=16,source_top_terms=len(top),source_maximal_Y_terms=len(keep),isolated_source_word=[['Tau','S']]*4,positive_T_polynomial=q,final_coefficient='3200 * mu * (2*C_source + 64*T^6) * a_Tau^4 * q(T)',proof='No objective degree24 word reaches Y-count16. The only competing maximum-Y terms contain the raw H61.K word XYYYYYY or its reverse, hence at least six consecutive Ys; the chosen cyclic word has maximum Y-run four. Tau^4 alone contributes twice q(T), and final 800-fold symmetrization gives 3200 q(T).',decoder_assumptions=['Tau.S leading decoder is a_Tau*YYY with a_Tau>0','Other assigned leading decoders are the recorded reversal-even or reversal-odd words with positive scales','All centering lowers degree, or at the same degree strictly lowers Y-count'],geometric_compatibility='Both audited full36 encoders satisfy these assumptions. Commuting-anchor even centering is scalar; odd centering uses raw2 XY-YX and raw3 XXY-YXX. At ordinary raw degree3 the latter strictly lowers Y-count. The arbitrary-second-anchor encoder only uses raw2 odd centering.')
(ROOT/'top_cyclic_degree_certificate.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
