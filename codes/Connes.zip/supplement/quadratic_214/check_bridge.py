#!/usr/bin/env python3
"""Independent standard-library audit. Never imports or executes proof generators.
Run in any directory; all proof data are local compressed JSON inputs.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import ast,gzip,hashlib,itertools,json,math
P=Path(__file__).resolve().parent
manifest=json.loads((P/'input_manifest.json').read_text())
def load(n):
 raw=gzip.decompress((P/'inputs'/f'{n}.json.gz').read_bytes())
 assert hashlib.sha256(raw).hexdigest()==manifest[n]['sha256'],n
 return json.loads(raw)
S,N,R,C,I,E,A=[load(n) for n in ['compact','native57','root','compression','integer','extension','assembled']]
class Words:
 def __init__(self,variables,unitaries=()):
  self.V=set(variables);self.U=set(unitaries);assert self.U<=self.V
 def letter(self,x):
  assert isinstance(x,str)
  a=x[:-1] if x.endswith('*') else x
  assert a in self.V and '*' not in a,x
  return x if a in self.U else a
 def starletter(self,x):
  x=self.letter(x)
  return x[:-1] if x.endswith('*') else x+'*' if x in self.U else x
 def red(self,w):
  out=[]
  for x in w:
   x=self.letter(x)
   if out and out[-1]==self.starletter(x):out.pop()
   else:out.append(x)
  return tuple(out)
 def inv(self,w):return self.red([self.starletter(x) for x in reversed(w)])
 def mul(self,*ws):return self.red(itertools.chain.from_iterable(ws))
 def trace(self,w):
  q=self.red(w)
  while len(q)>=2 and q[0]==self.starletter(q[-1]):q=q[1:-1]
  return min((q[i:]+q[:i] for i in range(len(q))),default=())
 def relkey(self,l,r):
  q=self.mul(l,self.inv(r));return min(self.trace(q),self.trace(self.inv(q)))
def rows(source):
 r={x['name']:x for x in source['residuals']};assert len(r)==len(source['residuals']);return r
assert len(S['variables'])==len(set(S['variables']))==33
assert len(S['unitary_variables'])==len(set(S['unitary_variables']))==12
W=Words(S['variables'],S['unitary_variables']);sr=rows(S)
assert len(sr)==78
# Regression guard: no unitary, in particular a root, cancels with itself.
for x in W.U:assert W.red([x,x])==(x,x) and W.red([x,x+'*'])==()
for x in W.V-W.U:assert W.red([x,x])==()
for row in sr.values():W.red(row['positive_word']);W.red(row['negative_word'])
def check_dag(data):
 checked=[]
 for number,node in enumerate(data['dag']):
  assert node['id']==number
  l,r=tuple(node['lhs']),tuple(node['rhs']);k=node['cost']
  assert type(k) is int and k>=0 and W.red(l)==l and W.red(r)==r
  refs=node['refs'];assert all(type(x) is int and 0<=x<number for x in refs)
  parents=[checked[x] for x in refs];op=node['kind']
  if op=='paid':
   z=sr[node['name']];expected=(W.red(z['positive_word']),W.red(z['negative_word']),1);assert not refs
  elif op=='reflexive':assert not refs and l==r;expected=(l,l,0)
  elif op=='reverse':
   assert len(refs)==1;x,y,c=parents[0];expected=(y,x,c)
  elif op=='adjoint':
   assert len(refs)==1;x,y,c=parents[0];expected=(W.inv(x),W.inv(y),c)
  elif op=='multiply':
   assert len(refs)==2;x,y,c=parents[0];z,t,d=parents[1];expected=(W.mul(x,z),W.mul(y,t),c+d)
  elif op=='transitive':
   assert len(refs)==2;x,y,c=parents[0];z,t,d=parents[1];assert y==z;expected=(x,t,c+d)
  elif op=='cyclic-relator':
   assert len(refs)==1;x,y,c=parents[0];assert W.relkey(l,r)==W.relkey(x,y);expected=(l,r,c)
  else:raise AssertionError(op)
  assert (l,r,k)==expected,(number,op)
  checked.append(expected)
 return checked
def check_goals(goals,verified):
 for n,g in goals.items():assert (tuple(g['lhs']),tuple(g['rhs']),g['cost'])==verified[g['id']],n
vr=check_dag(R);vc=check_dag(C)
check_goals(R['selected'],vr);check_goals(C['goals'],vc)
assert len(C['goals'])==42
# Check author root-only coverage too; no goal's data can invent a bound.
rootmap={n:W.red(w) for n,w in R['source57_virtual_coordinates'].items()}
def evaluate(w,sub,alg=W):
 return alg.mul(*[alg.inv(sub[x[:-1]]) if x.endswith('*') else sub[x] for x in w])
rootrows={r['name']:r for r in N['residuals'] if all(x.rstrip('*') in rootmap for x in r['left']+r['right'])}
assert set(rootrows)==set(R['source57_rows']) and len(rootrows)==102
for name,row in rootrows.items():
 g=R['source57_rows'][name]
 assert (evaluate(row['left'],rootmap),evaluate(row['right'],rootmap),g['cost'])==vr[g['id']]
assert sum(x['cost']**2 for x in R['source57_rows'].values())==2548771
print('PASS: all 2005 root and 2875 compression DAG nodes; root102 coverage',flush=True)

# Integer path: reconstruct old63->mixed160->native157 from input words.
O,M,H,T,D,D12,D15=[load(n) for n in ['old63','mixed160','native157','transfer157','historical','delete12','delete15']]
orows,mrows,hrows,drows=map(rows,[O,M,H,D])
struct=W.V-W.U
assert len(struct)==21 and struct<=set(O['variables'])
OW=Words(O['variables'])
oldsub={x:(x,) if x in struct|{'Esign13'} else () for x in O['variables']}
assert E['old63_variables']=={k:list(v) for k,v in oldsub.items()}
oldcharges=Counter();oldcounts=Counter()
for r in O['residuals']:
 n=r['name'];l=OW.red(itertools.chain.from_iterable(oldsub[x] for x in r['positive_word']));rgt=OW.red(itertools.chain.from_iterable(oldsub[x] for x in r['negative_word']))
 if l==rgt:bound={};kind='zero_after_field_specialization'
 elif n=='factor_sign13_R31':
  assert (l,rgt)==(('Dsign13','R31'),('Esign13',))
  assert (sr[n]['positive_word'],sr[n]['negative_word'])==(['Dsign13','R31'],['R31','Dsign13'])
  bound={n:Fraction(1,2)};kind='spectral_sign'
 elif n=='tau_comm_W12':
  assert (l,rgt)==(('Tau','W12'),('W12','Tau'))
  for name,a,b in [('perm_braid_B',['W23','W13'],['W12','W23']),('frob_comm_W23',['Tau','W23'],['W23','Tau']),('tau_comm_W13',['Tau','W13'],['W13','Tau'])]:
   assert (sr[name]['positive_word'],sr[name]['negative_word'])==(a,b)
  bound={'perm_braid_B':10,'frob_comm_W23':10,'tau_comm_W13':5};kind='three_letter_conjugation'
 else:
  n2={'tau_comm_Fgraph':'frob_comm_Fgraph','tau_comm_Ggraph':'frob_comm_Ggraph'}.get(n,n)
  assert (l,rgt)==(tuple(sr[n2]['positive_word']),tuple(sr[n2]['negative_word'])),n
  bound={n2:1};kind='retained'
 oldcharges.update(bound);oldcounts[kind]+=1
 er=next(x for x in E['old63_rows'] if x['old_row']==n)
 assert er['kind']==kind and {k:Fraction(v) for k,v in er['squared_bound'].items()}==bound
assert max(oldcharges.values())==11
MW=Words(M['variables'],M['unitary_variables']);assert set(M['involution_variables'])==MW.V-MW.U
assert len(MW.V)==160 and len(MW.U)==37
seen=set();fresh=set();counts=Counter()
for n,r in orows.items():
 a,b=r['positive_word'],r['negative_word']
 if n in mrows:
  assert r==mrows[n];seen.add(n);counts['retained']+=1
 elif 'factor_sym_'+n in mrows:
  row=mrows['factor_sym_'+n];h=row['negative_word'];assert len(h)==1
  assert row['positive_word']==a and len(a)==2 and b==a[::-1]
  assert h[0] in MW.V-MW.U and h[0] not in O['variables'] and h[0] not in fresh
  fresh.add(h[0]);seen.add(row['name']);counts['symmetry']+=1
 else:
  left,right=[mrows['factor_unit'+z+'_'+n] for z in ['L','R']]
  assert left['positive_word']==a and right['positive_word']==b and left['negative_word']==right['negative_word']
  h=left['negative_word'];assert len(h)==1 and h[0] in MW.U and h[0] not in fresh
  fresh.add(h[0]);seen.update([left['name'],right['name']]);counts['unitary']+=1
assert seen==set(mrows) and set(O['variables'])|fresh==MW.V
assert counts=={'retained':65,'symmetry':60,'unitary':37}
for r in M['residuals']:MW.red(r['positive_word']);MW.red(r['negative_word'])
virt=T['virtual_old_variables'];assert set(virt)==set(H['variables'])
for x,w in virt.items():
 assert not set(w)&MW.U
 assert MW.red(w)==MW.inv(w) and MW.mul(w,w)==(),x
assert T['old_source_sha256']==manifest['native157']['sha256'] and T['new_source_sha256']==manifest['mixed160']['sha256']
HW=Words(H['variables']);nonzero={}
for n,r in hrows.items():
 for side in ['left','right']:
  assert len(r[side])==1 and Fraction(r[side][0]['coefficient'])==1
 if HW.red(r['left'][0]['word'])!=HW.red(r['right'][0]['word']):nonzero[n]=r
proofs={q['name']:q for q in T['proofs']}
assert set(proofs)==set(nonzero) and len(proofs)==528
charges=Counter();termcount=0
for name,r in nonzero.items():
 proof=proofs[name]
 l=evaluate(r['left'][0]['word'],virt,MW);rgt=evaluate(r['right'][0]['word'],virt,MW)
 assert tuple(proof['lhs'])==l and tuple(proof['rhs'])==rgt
 poly=Counter({l:1});poly[rgt]-=1;mass=0
 for term in proof['terms']:
  c=term['coefficient'];assert type(c) is int and c!=0 and type(term['adjoint']) is bool
  rr=mrows[term['row']];a,b=rr['positive_word'],rr['negative_word']
  if term['adjoint']:a,b=MW.inv(a),MW.inv(b)
  poly[MW.mul(term['left'],a,term['right'])]-=c
  poly[MW.mul(term['left'],b,term['right'])]+=c
  mass+=abs(c);termcount+=1
 assert not {k:v for k,v in poly.items() if v},name
 assert mass==proof['cauchy_mass']
 for term in proof['terms']:charges[term['row']]+=mass*abs(term['coefficient'])
assert dict(charges)==T['charges'] and max(charges.values())==22869994 and termcount==128289
print('PASS: integer typed extensions and 528 signed ledgers / 128289 terms',flush=True)

# Reprove all 15 historical deletions using exact-structural-symmetry ledgers.
# This avoids trusting a verifier's success flag or a hand-entered norm row.
integer={n:r for n,r in drows.items() if r['group'] in {'integer_replacements','flips_and_commutations','diagonal_commutations'}}
assert len(integer)==48
ivars={x for r in integer.values() for side in ['positive_word','negative_word'] for x in r[side]}
IW=Words(ivars)
assert all(x in virt for x in ivars)
retained=set(integer)-set(D15['deleted_rows']);assert len(retained)==33
for n in retained:
 assert hrows[n]['left'][0]['word']==integer[n]['positive_word'] and hrows[n]['right'][0]['word']==integer[n]['negative_word']
def atom(name):return [(name,1,(),(),False)]
def plus(*ps):return sum(ps,[])
def scale(p,c):return [(n,c*k,l,r,a) for n,k,l,r,a in p]
def ctx(p,l=(),r=()):return [(n,k,IW.mul(l,ll),IW.mul(rr,r),a) for n,k,ll,rr,a in p]
def adj(p):return [(n,k,IW.inv(r),IW.inv(l),not a) for n,k,l,r,a in p]
def ledger_balance(p):
 q=Counter()
 for n,k,l,r,a in p:
  rr=integer[n];x,y=rr['positive_word'],rr['negative_word']
  if a:x,y=IW.inv(x),IW.inv(y)
  q[IW.mul(l,x,r)]+=k;q[IW.mul(l,y,r)]-=k
 return {w:c for w,c in q.items() if c}
def check_ledger(name,p):
 rr=integer[name];q=Counter({IW.red(rr['positive_word']):1});q[IW.red(rr['negative_word'])]-=1
 assert {w:c for w,c in q.items() if c}==ledger_balance(p),name

def path_ledger(path,rename=lambda x:x):
 out=[];last=None
 for step in path:
  lo,hi,n,pre,suf,isadj=step['edge'];n=rename(n)
  a,b=integer[n]['positive_word'],integer[n]['negative_word']
  pre,suf=[rename(x) for x in pre],[rename(x) for x in suf]
  if isadj:a,b=IW.inv(a),IW.inv(b)
  l=IW.mul(pre,a,suf);r=IW.mul(pre,b,suf)
  assert (l,r)==(IW.red([rename(x) for x in lo]),IW.red([rename(x) for x in hi]))
  frm,to=[IW.red([rename(x) for x in step[k]]) for k in ['from','to']]
  assert (frm,to) in [(l,r),(r,l)]
  if last is not None:assert last==frm
  last=to
  out.append((n,1 if frm==l else -1,tuple(pre),tuple(suf),isadj))
 return out
rowpath=next(x['path'] for x in load('row_path')['results'] if x['candidate']=='row2')
diagpath=load('diagonal_path')['path'];assert len(rowpath)==11 and len(diagpath)==18
recon={}
recon['row2']=path_ledger(rowpath)
rename=lambda n:''.join({'1':'2','2':'3','3':'1'}.get(c,c) for c in n)
recon['row3']=scale(path_ledger(rowpath,rename),-1)
for i,j in itertools.combinations((1,2,3),2):
 ren=lambda n:''.join({'1':str(i),'2':str(j)}.get(c,c) for c in n)
 recon[f'diag{i}{j}']=path_ledger(diagpath,ren)
for k in (1,2,3):
 i,j=sorted({1,2,3}-{k});a,b,s=f'T{i}{k}',f'T{j}{k}',f'S{k}'
 r,d=f'R{i}{k}',f'R{j}{k}';h=f'stein_G{i}{j}{k}'
 recon[f'stein_G{j}{i}{k}']=ctx(adj(atom(h)),[b],[a])
 fa,fb=atom(f'flip_{k}_{i}{k}'),atom(f'flip_{k}_{j}{k}')
 recon[f'col{k}']=plus(ctx(adj(fa),r=[s,b]),scale(ctx(adj(fb),r=[s,a]),-1),ctx(adj(atom(h)),[s],[a]),scale(ctx(atom(h),[s,a]),-1))
for i,j in itertools.combinations((1,2,3),2):
 a,b,u,v,w=f'R{i}{j}',f'R{j}{i}',f'S{i}',f'S{j}',f'W{i}{j}'
 fua,fva,fub=[atom(n) for n in [f'flip_{i}_{i}{j}',f'flip_{j}_{i}{j}',f'flip_{i}_{j}{i}']]
 ew,cw,dg=atom(f'weyl_A{i}{j}'),atom(f'weyl_C{i}{j}'),atom(f'diag{i}{j}')
 ca=plus(ctx(fva,[u]),scale(ctx(adj(fua),r=[v]),-1))
 cq=plus(scale(ctx(adj(cw),[u]),-1),ctx(cw,r=[u]),scale(ctx(dg,[w]),-1))
 cb=plus(ctx(ew,[u,v,a]),scale(ctx(ew,[a],[u,v]),-1),ctx(ca,r=[w,a]),ctx(cq,[a],[a]),ctx(ca,[a,w]))
 recon[f'flip_{j}_{j}{i}']=plus(ctx(cb,[u]),ctx(fub,r=[u,v]))
# Reconstruct row1 from the proved row2 and four retained Steinberg/Weyl rows.
a,d,b,c='R12','R21','R23','R13'
z=plus(ctx(atom('stein_F213'),[d]),scale(ctx(atom('stein_F123'),[d], [a,d]),-1))
delta=plus(ctx(atom('weyl_A12'),r=[a]),scale(ctx(atom('weyl_B12'),r=[d]),-1))
recon['row1']=plus(ctx(z,[a]),scale(ctx(z,r=[a]),-1),ctx(delta,r=[b,a,d]),ctx(atom('row2'),[d,a],[a,d]),scale(ctx(delta,[d,a,b]),-1))
assert set(recon)==set(D15['deleted_rows'])
for name,ledger in recon.items():check_ledger(name,ledger)
def expand(p,stack=()):
 out=[]
 for n,k,l,r,a in p:
  if n in recon:
   assert n not in stack
   sub=expand(recon[n],stack+(n,))
   if a:sub=adj(sub)
   out+=scale(ctx(sub,l,r),k)
  else:assert n in retained;out.append((n,k,l,r,a))
 return out
independent_deleted={};reflection_charges=Counter({n:1 for n in retained})
for name in recon:
 ledger=expand(recon[name],(name,));check_ledger(name,ledger)
 normrow=Counter()
 for n,k,*_ in ledger:normrow[n]+=abs(k)
 assert all(v<=D15['deleted_rows'][name].get(n,0) for n,v in normrow.items()),(name,normrow)
 independent_deleted[name]=dict(normrow)
 for n,v in normrow.items():reflection_charges[n]+=sum(normrow.values())*v
assert max(reflection_charges.values())<=985
print('PASS: independently reconstructed all 15 deleted integer rows; squared charge '+str(max(reflection_charges.values())),flush=True)

# Check every recorded unitary path edge and each exact relation endpoint.
# Cubic Steinberg steps are checked as a two-row free polynomial identity.
rules={n:(tuple(r['positive_word']),tuple(r['negative_word']),1) for n,r in integer.items()}
for v in ivars:rules['exact_involution_'+v]=((v,v),(),0)
for i,j,k in itertools.permutations((1,2,3)):
 a,b,t,s,u=f'R{i}{j}',f'R{j}{k}',f'T{i}{k}',f'S{k}',f'T{j}{k}'
 p=plus(ctx(atom(f'stein_F{i}{j}{k}'),r=[a]),ctx(atom(f'stein_G{i}{j}{k}'),[t]))
 want=Counter({IW.red([a,b,a]):1});want[IW.red([t,s,u])]-=1
 assert ledger_balance(p)=={w:c for w,c in want.items() if c}
 rules[f'cubic_stein_{i}{j}{k}']=((a,b,a),(t,s,u),2)
paths={p['name']:p for p in E['unitary_paths']};assert len(paths)==15
U={}
for i,j in itertools.permutations((1,2,3),2):
 U[i,j]=MW.mul(virt[f'R{i}{j}'],virt[f'S{j}'])
 assert set(U[i,j])<=struct
expected={}
for i in (1,2,3):
 j,k=sorted({1,2,3}-{i})
 expected[f'unitary_row{i}']=([f'R{i}{j}',f'S{j}',f'R{i}{k}',f'S{k}'],[f'R{i}{k}',f'S{k}',f'R{i}{j}',f'S{j}'])
 expected[f'unitary_col{i}']=([f'R{j}{i}',f'S{i}',f'R{k}{i}',f'S{i}'],[f'R{k}{i}',f'S{i}',f'R{j}{i}',f'S{i}'])
for i,j,k in itertools.permutations((1,2,3)):
 expected[f'unitary_stein{i}{j}{k}']=([f'R{i}{j}',f'S{j}',f'R{j}{k}',f'S{k}'],[f'R{i}{k}',f'S{k}',f'R{j}{k}',f'S{k}',f'R{i}{j}',f'S{j}'])
for i,j in itertools.combinations((1,2,3),2):
 expected[f'unitary_opposite{i}{j}']=([f'R{i}{j}',f'S{j}',f'S{i}',f'R{j}{i}',f'R{i}{j}',f'S{j}'],[f'S{i}',f'R{j}{i}',f'R{i}{j}',f'S{j}',f'S{i}',f'R{j}{i}'])
for name,p in paths.items():
 assert len(p['edges'])==len(p['words'])-1
 assert IW.red(p['words'][0])==IW.red(expected[name][0]) and IW.red(p['words'][-1])==IW.red(expected[name][1])
 costs=[]
 for old,new,edge in zip(p['words'],p['words'][1:],p['edges']):
  l,r,c=rules[edge['row']]
  if edge['adjoint']:l,r=l[::-1],r[::-1]
  if edge['reverse']:l,r=r,l
  assert tuple(edge['prefix'])+l+tuple(edge['suffix'])==tuple(old)
  assert tuple(edge['prefix'])+r+tuple(edge['suffix'])==tuple(new)
  assert c==edge['cost'];costs.append(c)
 assert sum(costs)==p['norm_cost'] and sum(costs)<=11

# Audit action conjugacy signed ledgers using mixed-star compact algebra.
conjugators={(2,1):(),(1,2):('W12',),(3,1):('W23',),(1,3):('W23','W12'),(2,3):('W13',),(3,2):('W12','W23')}
acts={ij:W.mul(p,['R21','S1'],W.inv(p)) for ij,p in conjugators.items()}
for ij,u in U.items():
 name='U'+''.join(map(str,ij));proof=E['action_conjugacy'][name]
 assert W.red(proof['lhs'])==u and W.red(proof['rhs'])==acts[ij]
 q=Counter({u:1});q[acts[ij]]-=1;mass=0
 for term in proof['terms']:
  row=sr[term['row']];l,r=row['positive_word'],row['negative_word'];coeff=term['coefficient']
  assert set(l+r+term['left']+term['right'])<=struct
  if term['adjoint']:l,r=W.inv(l),W.inv(r)
  q[W.mul(term['left'],l,term['right'])]-=coeff
  q[W.mul(term['left'],r,term['right'])]+=coeff
  mass+=abs(coeff)
 assert not {w:c for w,c in q.items() if c} and mass==proof['norm_cost']<=8
 assert list(u)==I['unitary_action_words'][name] and list(acts[ij])==I['conjugate_action_words'][name]
 assert acts[ij]==W.red(C['first_actions'][str(ij)])
reflection_bound=11*22869994*985
assert reflection_bound==247796384990
ceiling=math.isqrt(reflection_bound)+1
assert 11*ceiling+48<2**23
print('PASS: all 15 unitary endpoints and rewrite paths, six action-conjugacy ledgers',flush=True)

# Build the full native57 fill independently, using declared structural words.
assert N['coordinate_type']=='genuine unitary' and len(N['coordinates'])==len(set(N['coordinates']))==57
perm={0:0,1:2,2:1,3:3}
d={0:('d0_0',),2:W.mul(['B2','d0_0','B2'])}
d[1]=W.mul(['W12'],d[2],['W12']);d[3]=W.mul(['W23'],d[2],['W23'])
e={i:W.mul(['Fgraph'],d[i],['Fgraph']) for i in d}
products={(1,2):('p12_0',),(1,3):('W23','p12_0','W23'),(2,3):('W13','p12_0','W13')}
sub={'x':('x0',),'y':('y0',),'c':('c0',)}
for i in range(4):
 sub['z'+str(i)]=(f'z{perm[i]}_0',);sub['d'+str(i)]=d[perm[i]];sub['e'+str(i)]=e[perm[i]]
for i,j in itertools.combinations((1,2,3),2):sub[f'p{i}{j}']=W.red(products[tuple(sorted([perm[i],perm[j]]))])
for i,j in itertools.permutations((1,2,3),2):sub[f'u{i}{j}']=acts[perm[i],perm[j]]
sub['t']=W.mul(['V'],['R21','S1'])
u=sub['u12'];h=sub['z2'];t=sub['t']
assert u==('R21','S1') and h==('z1_0',)
sub['P']=W.mul(W.inv(u),h,u);sub['Q']=W.mul(W.inv(t),h,t)
progress=True
while progress:
 progress=False
 for row in N['residuals']:
  if len(row['left'])==1 and row['left'][0] not in sub and all(x.rstrip('*') in sub for x in row['right']):
   sub[row['left'][0]]=evaluate(row['right'],sub);progress=True
assert set(sub)==set(N['coordinates'])
for word in sub.values():assert W.mul(word,W.inv(word))==() # genuine unitary words; not root squares
assert {n:list(w) for n,w in sub.items()}==A['virtual_coordinates']
assert list(sub['P'])==C['signals']['P'] and list(sub['Q'])==C['signals']['Q']
assert list(sub['t'])==C['second_action']
pool={}
def register(kind,name,l,r,cost):pool.setdefault(W.relkey(l,r),[]).append((cost,kind,name))
for name,g in R['selected'].items():register('root',name,g['lhs'],g['rhs'],g['cost'])
for name,g in C['goals'].items():register('compression',name,g['lhs'],g['rhs'],g['cost'])
for i in (1,2,3):
 j,k=sorted({1,2,3}-{i})
 for a,b,label in [(acts[i,j],acts[i,k],'row'),(acts[j,i],acts[k,i],'column')]:register('integer',label+str(i),W.mul(a,b),W.mul(b,a),2**23)
for i,j,k in itertools.permutations((1,2,3)):
 a,b,c=acts[i,j],acts[j,k],acts[i,k];register('integer',f'stein{i}{j}{k}',W.mul(a,b),W.mul(c,b,a),2**23)
for i,j in itertools.combinations((1,2,3),2):
 a,b=acts[i,j],acts[j,i];register('integer',f'opposite{i}{j}',W.mul(a,W.inv(b),a),W.mul(W.inv(b),a,W.inv(b)),2**23)
coverage=[];kinds=Counter();charge=0
assert len(rows(N))==170
for r in N['residuals']:
 l,rgt=evaluate(r['left'],sub),evaluate(r['right'],sub)
 if l==rgt:cost,kind,goal=0,'zero','free-unitary identity'
 else:
  key=W.relkey(l,rgt);assert key in pool,r['name'];cost,kind,goal=min(pool[key])
 kinds[kind]+=1;charge+=cost**2
 coverage.append(dict(row=r['name'],lhs=list(l),rhs=list(rgt),cost=cost,bound_source=kind,certificate_goal=goal))
assert kinds=={'root':81,'integer':15,'compression':42,'zero':32}
assert charge==1055531165250989<2**56
assert coverage==A['row_coverage'] and charge==A['exact_squared_charge']
def tracepoly(terms):
 p=Counter()
 for coefficient,word in terms:p[W.trace(word)]+=Fraction(coefficient)
 return {w:c for w,c in p.items() if c}
compactobjective=tracepoly([(x['coefficient'],x['word']) for x in S['parts']['F0']])
nativeobjective=tracepoly([(c,evaluate(w,sub)) for c,w in N['objective']])
expectedobjective=tracepoly([(-1,()),(1,('V','z1_0*','V','z1_0')),(1,('z1_0*','V','z1_0','V'))])
assert compactobjective==nativeobjective==expectedobjective
# Explicit norm identity: 1-[V,A]^*[V,A] has exactly this trace polynomial.
a=('z1_0',);v=('V',);va=W.mul(v,a);av=W.mul(a,v)
normidentity=tracepoly([(1,()),(-1,W.mul(W.inv(va),va)),(1,W.mul(W.inv(va),av)),(1,W.mul(W.inv(av),va)),(-1,W.mul(W.inv(av),av))])
assert normidentity==compactobjective
summary={
 'status':'PASS_INDEPENDENT_FULL_TYPED_SOURCE33_TO_NATIVE57_BRIDGE',
 'root_dag_nodes':len(vr),'compression_dag_nodes':len(vc),'root_partial_rows':102,
 'mixed_star_unitaries':12,'structural_symmetries':21,'compact_paid_rows':78,
 'old63_extension_max_squared_charge':11,'mixed160_extension_max_squared_charge':1,
 'native157_signed_ledgers':len(proofs),'native157_context_terms':termcount,'native157_max_squared_charge':22869994,
 'independently_reproved_deleted_rows':len(recon),'independent_restricted_deletion_charge':max(reflection_charges.values()),
 'conservative_deletion_charge_used':985,'original_unitary_paths':len(paths),
 'integer_ceil_sqrt_reflection_bound':ceiling,'integer_norm_bound_before_rounding':11*ceiling+48,'integer_rounded_norm_bound':2**23,
 'coverage_counts':dict(kinds),'exact_squared_charge':charge,'convenient_squared_charge':2**56,
 'objective_exact_in_trace':True,
 'typed_conclusion':'tr(Fcompact + 2^56 mu5 Q33) >= (3/4) tr(p) in every finite-dimensional correctly typed corner p',
 'native_theorem_premise':'native57 F5 matrix separation with mu5=2^(2J5+30), J5=2^(2^1122100)',
 'scope':'Finite bridge proved from actual word data. Native57 analytic correction/normalization/spectral imports remain stated premises; witness separately audited.',
}
(P/'audit_result.json').write_text(json.dumps(summary,indent=2)+'\n')
(P/'independent_coverage.json').write_text(json.dumps({'coordinates':{k:list(v) for k,v in sub.items()},'rows':coverage,'deletion_norm_rows':independent_deleted},indent=2)+'\n')
print(json.dumps(summary,indent=2))
