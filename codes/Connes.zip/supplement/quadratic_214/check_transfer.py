#!/usr/bin/env python3
"""Independent F2 specialization/rebase of finite signed-word DAG data.
No proof generator is imported. All values, words, and polynomials are immutable.
The separately replayed integer dependency proves its historical finite bound;
this script checks every compact row and action used to import that bound.
"""
from pathlib import Path
from collections import Counter
from fractions import Fraction as Q
import json, hashlib, math
P=Path(__file__).resolve().parent
for _name,_digest in json.loads((P/'input_manifest.json').read_text()).items():
    assert hashlib.sha256((P/_name).read_bytes()).hexdigest()==_digest,_name

I=P/'inputs'
def load(n):return json.loads((I/n).read_text())
O=load('f2_compact32_79rows_torus_bridge.json');S=load('f2_compact32_79rows_cubic.json')
F=load('f5_source33.json');R=load('root_bridge_certificate.json');C=load('compression_bridge_certificate.json')
T=load('integer_transfer.json');E=load('integer_transfer_extension.json')
orows={r['name']:r for r in O['residuals']};srows={r['name']:r for r in S['residuals']}
frows={r['name']:r for r in F['residuals']}
V=set(O['variables'])
assert len(V)==32 and not O['unitary_variables'] and not S['unitary_variables']
assert len(orows)==len(srows)==79
assert max(len(r[k]) for r in S['residuals'] for k in ('positive_word','negative_word'))==3

def red(w):
 out=[]
 for letter in w:
  a=letter.rstrip('*');assert a in V,(a,w)
  if out and out[-1]==a:out.pop()
  else:out.append(a)
 return tuple(out)
def inv(w):return red(tuple(w)[::-1])
def cat(*ws):return red(a for w in ws for a in w)
def trace(w):
 w=red(w)
 while len(w)>1 and w[0]==w[-1]:w=w[1:-1]
 return min((w[j:]+w[:j] for j in range(len(w))),default=())
def relkey(a,b):
 w=cat(a,inv(b));return min(trace(w),trace(inv(w)))
def rowpair(r):return red(r['positive_word']),red(r['negative_word'])

# Exact derivation of missing F5 centrality premises after symmetry specialization.
# k=xyxy, ||c-k||<=2eps from the two paid xy rows; c=c*, x=x*, y=y*.
x,y,c,K='x0','y0','c0','Kxy_00'
k=(x,y,x,y)
assert rowpair(orows['cross_F_xy_00'])==((x,y),(K,x))
assert rowpair(orows['normal_diag_product'])==((K,y),(c,))
def balance(target,terms):
 d=Counter({red(target[0]):1,red(target[1]):-1})
 for n,coef,left,right,adj in terms:
  a,b=rowpair(orows[n])
  if adj:a,b=inv(a),inv(b)
  d[cat(left,a,right)]-=coef;d[cat(left,b,right)]+=coef
 assert not {w:v for w,v in d.items() if v},(target,d)
ck=[('normal_diag_product',-1,(),(),False),('cross_F_xy_00',-1,(),(x,y),False)]
balance(((c,),k),ck)
def adjterms(ts):return [(n,z,inv(r),inv(l),not a) for n,z,l,r,a in ts]
def context(ts,l=(),r=()):return [(n,z,cat(l,ll),cat(rr,r),a) for n,z,ll,rr,a in ts]
def neg(ts):return [(n,-z,l,r,a) for n,z,l,r,a in ts]
# [c,x]=(c-k)x - x(c-k*) and [c,y]=(c-k*)y-y(c-k).
balance(((c,x),(x,c)),context(ck,r=(x,))+neg(context(adjterms(ck),l=(x,))))
balance(((c,y),(y,c)),context(adjterms(ck),r=(y,))+neg(context(ck,l=(y,))))
central={'field_central_x_c':((c,x),(x,c),4),'field_central_y_c':((c,y),(y,c),4)}

def audit_subset(data,goals):
 nodes=data['dag'];need=set()
 def visit(i):
  if i in need:return
  assert 0<=i<len(nodes) and nodes[i]['id']==i
  need.add(i)
  for j in nodes[i]['refs']:assert j<i;visit(j)
 for g in goals.values():visit(g['id'])
 checked={};paid=set()
 for i in sorted(need):
  n=nodes[i];l,r=red(n['lhs']),red(n['rhs']);refs=n['refs'];ps=[checked[j] for j in refs];op=n['kind']
  if op=='paid':
   name=n['name'];paid.add(name);assert not refs
   if name in central:expected=(*rowpair(frows[name]),4)
   else:expected=(*rowpair(orows[name]),1)
  elif op=='reflexive':assert not refs and l==r;expected=l,r,0
  elif op=='reverse':assert len(ps)==1;a,b,k=ps[0];expected=b,a,k
  elif op=='adjoint':assert len(ps)==1;a,b,k=ps[0];expected=inv(a),inv(b),k
  elif op=='multiply':
   assert len(ps)==2;a,b,k=ps[0];d,e,j=ps[1];expected=cat(a,d),cat(b,e),k+j
  elif op=='transitive':
   assert len(ps)==2;a,b,k=ps[0];d,e,j=ps[1];assert b==d;expected=a,e,k+j
  elif op=='cyclic-relator':
   assert len(ps)==1;a,b,k=ps[0];assert relkey(l,r)==relkey(a,b);expected=l,r,k
  else:raise AssertionError(op)
  assert (l,r)==expected[:2],(i,op,(l,r),expected)
  checked[i]=expected
 result={}
 for name,g in goals.items():
  a,b,k=checked[g['id']];assert (a,b)==(red(g['lhs']),red(g['rhs']))
  result[name]={'lhs':a,'rhs':b,'cost':k}
 return result,sorted(paid),len(need)

cg,cp,cn=audit_subset(C,C['goals'])
rgkeys=[f'{a}z{i}_cross' for a in ('x','y') for i in range(4)]+[f'prod{a}{b}_cross' for a,b in ((1,2),(2,1),(1,3),(3,1),(2,3),(3,2))]
rg,rp,rn=audit_subset(R,{n:R['selected'][n] for n in rgkeys})
assert len(cg)==42 and max(g['cost'] for g in cg.values())==90
assert all('order5' not in n and n!='frob_Q_definition' for n in cp+rp)
rootcost=max(rg[f'{a}z{i}_cross']['cost'] for a in ('x','y') for i in range(4))
prodcost=max(rg[n]['cost'] for n in rg if n.startswith('prod'))
product_word_error=prodcost+4*rootcost
assert product_word_error<4096
# Verify every product target and each corresponding d/e commutator route.
for a,b in ((1,2),(2,1),(1,3),(3,1),(2,3),(3,2)):
 d=red(R['virtual_coordinates'][f'd{a}']);e=red(R['virtual_coordinates'][f'e{b}'])
 p=red(C['products'][str(tuple(sorted((a,b))))])
 g=rg[f'prod{a}{b}_cross'];assert g['lhs']==cat(d,e) and g['rhs']==cat(p,e,d)
 for A,root,prefix in ((a,d,'x'),(b,e,'y')):
  z=(f'z{A}_0',);base=(prefix+'0',);q=rg[f'{prefix}z{A}_cross']
  assert q['lhs']==cat(base,z) and q['rhs']==cat(root,z,base)

# All 37 compact integer charge rows and seven action-comparison rows specialize
# literally; the missing frob_Q_definition reduces to Tau^2=1 exactly.
integer_rows=set(E['compact_squared_column_charges'])
integer_rows|={t['row'] for p in E['action_conjugacy'].values() for t in p['terms']}
for n in integer_rows:assert rowpair(frows[n])==rowpair(orows[n]),n
for action,goal in E['action_conjugacy'].items():
 d=Counter();d[red(goal['lhs'])]+=1;d[red(goal['rhs'])]-=1
 for t in goal['terms']:
  a,b=rowpair(orows[t['row']]);
  if t['adjoint']:a,b=inv(a),inv(b)
  d[cat(t['left'],a,t['right'])]-=t['coefficient'];d[cat(t['left'],b,t['right'])]+=t['coefficient']
 assert not {w:v for w,v in d.items() if v},action
 assert red(goal['rhs'])==red(T['conjugate_action_words'][action])
 key=str(tuple(map(int,action[1:])))
 assert red(goal['rhs'])==red(C['first_actions'][key])
A=11*22869994*985
assert A==247796384990
assert 26*(11*(math.isqrt(A)+1)+48)<2**28

# Independently check cubic rebasing transport ledgers and squared column bound.
# B2=p B1 p. All unchanged old73 rows match literally.
newV=set(S['variables']);assert V-{'B2'}==newV-{'B1'}
def newred(w):
 out=[]
 for a in w:
  assert a in newV
  if out and out[-1]==a:out.pop()
  else:out.append(a)
 return tuple(out)
def sub(w):return newred(a for x in w for a in (('W12','B1','W12') if x=='B2' else (x,)))
changed=[n for n,r in orows.items() if 'B2' in r['positive_word']+r['negative_word'] and not n.startswith('torus_')]
assert len(changed)==3
# Preserve old row names across rebase. Cauchy charges from explicit 3,3,4 routes.
charges=Counter()
for n,r in orows.items():
 if n.startswith('torus_'):continue
 if n not in changed:
  assert (sub(r['positive_word']),sub(r['negative_word']))==(newred(srows[n]['positive_word']),newred(srows[n]['negative_word'])),n
  charges[n]+=1
# Every norm bound below is derived by conjugation by p and the listed three/four replacements.
# Verify corresponding rebase formulas with a finite search over exact contextual rewrites.
p='W12';B='B1';C1='C1';C2='C2';f='Fgraph'
rebase_specs={
 'base_comm_B2_x0':None,
}
# Actual names are read from the literal old source and classified by word shape.
rebase=[]
for name in changed:
 a,b=orows[name]['positive_word'],orows[name]['negative_word']
 if set(a+b)=={'B2','x0'}:uses=['bcov_W12_x0',name,'bcov_W12_x0']
 elif set(a+b)=={'B2','C1'}:uses=['weyl_C2',name,'weyl_C2']
 elif set(a+b)=={'Fgraph','B2','C2'}:uses=['bcov_W12_Fgraph',name,'weyl_C2','bcov_W12_Fgraph']
 else:raise AssertionError((name,a,b))
 cost=len(uses)
 for n in uses:charges[n]+=cost
 # Breadth-first finite free-word rewrites, each consuming one of the specified rows.
 # Cayley relator framing permits arbitrary side orientation/inversion, unitary contexts.
 target=(sub(a),sub(b));seen={(target[0],tuple(sorted(Counter(uses).items())))};front=list(seen);found=False
 while front:
  w,remaining=front.pop(0);d=dict(remaining)
  if w==target[1]:found=True;break
  for n,count in list(d.items()):
   if not count:continue
   rr=srows[n];aa=tuple(rr['positive_word']);bb=tuple(rr['negative_word'])
   rules=[(aa,bb),(bb,aa),(aa[::-1],bb[::-1]),(bb[::-1],aa[::-1])]
   # Cyclic reframing supplies short boundary-cancelled equalities too.
   rel=newred(aa+bb[::-1])
   for relator in (rel,rel[::-1]):
    for j in range(len(relator)):
     rrw=relator[j:]+relator[:j]
     for cut in range(1,len(rrw)):
      rules.append((rrw[:cut],rrw[cut:][::-1]))
   for lhs,rhs in rules:
    for pos in range(len(w)-len(lhs)+1):
     if w[pos:pos+len(lhs)]==lhs:
      ww=newred(w[:pos]+rhs+w[pos+len(lhs):]);dd=dict(d);dd[n]-=1
      state=(ww,tuple(sorted(dd.items())))
      if state not in seen:seen.add(state);front.append(state)
  assert len(seen)<100000
 assert found,(name,target,uses)
 rebase.append({'row':name,'cost':cost,'uses':uses,'states_checked':len(seen)})
assert max(charges.values())==11
assert 2**28*4==2**30
# Objective equality in trace, checked after symmetry specialization.
psig=red(C['signals']['P']);qsig=red(C['signals']['Q'])
assert sorted([trace(cat(inv(psig),qsig)),trace(cat(inv(qsig),psig))])==sorted(trace(t['word']) for t in O['parts']['F0'] if t['word'])
assert O['parts']['F0']==S['parts']['F0']
report={'status':'PASS_CHAR2_PAID_COMPRESSION_INTEGER_AND_CUBIC_REBASE',
 'compression_goals':cg,'compression_nodes_replayed':cn,'compression_paid_rows':cp,
 'root_product_goals':rg,'root_product_nodes_replayed':rn,'root_product_paid_rows':rp,
 'root_cross_max_cost':rootcost,'product_cross_max_cost':prodcost,
 'product_six_root_word_length':16,'product_six_root_error_bound':product_word_error,
 'conservative_product_error_old_source':4096,'conservative_product_error_cubic_source':16384,
 'compression_error_old_source':90,'compression_error_cubic_source':360,
 'integer_rows_matched':len(integer_rows),'integer_spectral_C_old_source':2**28,
 'integer_spectral_C_cubic_source':2**30,'integer_lambda':'1/144','integer_h':6,
 'cubic_rebase_squared_bound':11,'cubic_rebase_ledger':rebase,
 'objective_exact_in_trace':True,
 'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(I.glob('*.json'))}}
(P/'transfer_result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['compression_goals','root_product_goals','input_sha256']},indent=2))
