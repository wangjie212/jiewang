#!/usr/bin/env python3
"""Independent verifier for the new 79-to-80 transfer certificate.

Uses only JSON sources and the published derivation data. No search code,
optimizer, numerical matrices, source witness, or historical PASS is imported.
Every primitive letter denotes an arbitrary exact symmetry. A step replaces
l by r inside a cyclic relator. Its defect is charged to a previously verified
source/helper cap equivalent to l r^{-1} by free, cyclic, inverse moves.
"""
import hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
EXPECTED={
 'base_32_symmetries_79_rows.json':'55aa41f9cf715287866e3c3244e437821b9932bdfbbeba1438cb7e061f00b148',
 'source_42_typed_82_rows.json':'af9f1d7e3cc55fea29e9d582b0409c7a949e36de3476baac1be949a913f123b2',
}
for name,digest in EXPECTED.items():
 assert hashlib.sha256((P/name).read_bytes()).hexdigest()==digest,(name,'hash')
base=json.loads((P/'base_32_symmetries_79_rows.json').read_text())
target=json.loads((P/'source_42_typed_82_rows.json').read_text())
cert=json.loads((P/'certificate_79_to_80.json').read_text())
codes=cert['codes']
assert set(codes)==set(target['variables'])-set(target['unitary_variables'])
assert len(codes)==40 and len(set(codes.values()))==40
assert all(len(c)==1 for c in codes.values())
assert len(base['variables'])==32 and not base['unitary_variables']
assert len(base['residuals'])==79 and len(target['residuals'])==82
assert set(base['variables'])-set(codes)=={'Kxy_00'}
assert set(target['unitary_variables'])=={'F2_torus_N','F2_steinberg_P'}

def freely_reduce(word):
 stack=[]
 for c in word:
  assert c in codes.values()
  if stack and stack[-1]==c: stack.pop()
  else: stack.append(c)
 return ''.join(stack)

def canonical_cap(word):
 word=freely_reduce(word)
 while len(word)>1 and word[0]==word[-1]:word=word[1:-1]
 if not word:return ''
 return min(v[k:]+v[:k] for v in (word,word[::-1]) for k in range(len(v)))

substitutions={'Kxy_00':['x0','y0','x0'],
 'F2_torus_N':['C1','B1'],'F2_steinberg_P':['x0','z0_0']}
def substitute(word):
 out=[]
 for token in word:
  adjoint=token.endswith('*');name=token[:-1] if adjoint else token
  expanded=substitutions.get(name,[name])
  if adjoint:expanded=list(reversed(expanded))
  out.extend(codes[x] for x in expanded)
 return ''.join(out)
def cap(row):
 return canonical_cap(substitute(row['positive_word'])+
                      substitute(row['negative_word'])[::-1])
source_caps={r['name']:cap(r) for r in target['residuals']}
assert source_caps==cert['sources']
zero=[n for n,w in source_caps.items() if not w]
assert set(zero)=={'torus_recovery_F2_torus_N','steinberg_recovery_F2_steinberg_P'}
assert len(source_caps)-len(zero)==80
known={name:(w,1) for name,w in source_caps.items()}
goals={r['name']:cap(r) for r in base['residuals']}
assert goals==cert['goals']
assert set(goals)<=set(cert['proofs']) and cert['remaining']==[]
step_count=0
for name,proof in cert['proofs'].items():
 current=proof['word'];assert current==canonical_cap(current)
 if name in goals:assert current==goals[name],(name,'wrong base cap')
 else:assert name.startswith('helper_'),name
 total=0
 for step in proof['path']:
  step_count+=1
  assert step['before']==current
  assert step['name'] in known,(name,'forward or missing rule',step['name'])
  reference,cost=known[step['name']]
  assert canonical_cap(step['l']+step['r'][::-1])==reference,(name,'invalid rule')
  assert cost==step['cost']
  assert 0<=step['rotation']<len(current)
  rotated=current[step['rotation']:]+current[:step['rotation']]
  assert rotated.startswith(step['l']) and step['l']
  result=canonical_cap(step['r']+rotated[len(step['l']):])
  assert result==step['after']
  current=result;total+=cost
 assert current=='' and total==proof['cost'],(name,'not proved')
 known[name]=(proof['word'],total)
C=sum(known[name][1]**2 for name in goals)
assert C==149778 and C<11156544672
assert len(cert['proofs'])==84
report={'status':'VERIFIED','base_rows':79,'target_symmetries':40,
 'target_nonzero_residuals':80,'proved_helper_caps':5,'total_paths':84,
 'literal_rewrite_steps':step_count,'sum_squared_norm_costs':C,
 'maximum_base_norm_cost':max(known[n][1] for n in goals),
 'historical_coefficient_factor':11156544672,
 'method':'Exact arbitrary-symmetry free-word, cyclic, inverse and contextual rewrites; Hilbert-Schmidt triangle inequality.'}
print(json.dumps(report,indent=2))
