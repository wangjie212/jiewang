#!/usr/bin/env python3
"""Audit printed SOS coefficients and application identities over the rationals.

Run beside the manuscript: python3 verify_manuscript.py
Requires SymPy only. This supplements, rather than replaces, the full
polynomial certificate in verify_four_dimensional_sos.py and the proofs.
"""
from __future__ import annotations

import json
from pathlib import Path
import re
import sympy as s
from sympy.parsing.sympy_parser import (
    implicit_multiplication_application, parse_expr, standard_transformations,
)

if not __debug__:
    raise RuntimeError('Run without -O: this verifier uses assertions.')

ROOT = Path(__file__).resolve().parent
VARIABLES = s.symbols('a b c d e f')
WEDGES = s.symbols('w12 w13 w14 w23 w24 w34')
NAMES = {str(x): x for x in (*VARIABLES, *WEDGES)}
PAIRS = ('12', '13', '14', '23', '24', '34')


def tex_polynomial(source: str) -> s.Expr:
    """Parse only the restricted polynomial TeX syntax used in the appendix.

    Reject unknown syntax, instead of silently dropping it. No third-party
    LaTeX parser is required. Fractions and integer powers remain exact.
    """
    source = source.replace('\\\\', ' ').replace('&', ' ').strip().rstrip(',;.')
    for command in ('\\left', '\\right', '\\quad', '\\bigl', '\\bigr'):
        source = source.replace(command, '')

    def group_at(pos: int) -> tuple[str, int]:
        while pos < len(source) and source[pos].isspace():
            pos += 1
        if pos >= len(source) or source[pos] != '{':
            raise ValueError('Expected a braced fraction argument')
        start, depth = pos+1, 1
        pos += 1
        while pos < len(source) and depth:
            depth += (source[pos] == '{') - (source[pos] == '}')
            pos += 1
        if depth:
            raise ValueError('Unbalanced braces')
        return source[start:pos-1], pos

    while '\\frac' in source:
        start = source.index('\\frac')
        numerator, end = group_at(start+5)
        denominator, end = group_at(end)
        source = source[:start] + f'(({numerator})/({denominator}))' + source[end:]
    source = source.replace('^', '**').replace('{', '(').replace('}', ')')
    source = ' '.join(source.split())
    if not re.fullmatch(r'[a-f0-9\s()+*/-]+', source):
        raise ValueError(f'Unsupported coefficient syntax: {source!r}')
    expression = parse_expr(
        source, local_dict=NAMES,
        transformations=standard_transformations+(implicit_multiplication_application,),
    )
    return s.Poly(expression, *VARIABLES, domain=s.QQ).as_expr()


def check_printed_coefficients() -> None:
    data = json.loads((ROOT/'tau_sos_polynomials.json').read_text())
    expected = {}
    for ell, entry in enumerate(data['squares'], 1):
        expression = s.sympify(entry['polynomial'], locals=NAMES)
        for pair, wedge in zip(PAIRS, WEDGES):
            expected[ell, pair] = s.expand(s.diff(expression, wedge))

    text = (ROOT/'03_certificate_coefficients.tex').read_text()
    actual = {}
    for block in re.findall(r'\\begin\{align\*\}(.*?)\\end\{align\*\}', text, re.S):
        matches = list(re.finditer(r'p_\{(\d+),(\d\d)\}\s*&=', block))
        for k, match in enumerate(matches):
            end = matches[k+1].start() if k+1 < len(matches) else len(block)
            key = int(match[1]), match[2]
            assert key not in actual, f'Duplicate printed coefficient {key}'
            actual[key] = tex_polynomial(block[match.end():end])
    assert set(actual) == set(expected), 'Printed coefficient list is incomplete'
    for key in expected:
        assert s.expand(actual[key]-expected[key]) == 0, f'TeX coefficient mismatch: {key}'
    print('PASS: all 60 printed TeX coefficients agree exactly with the JSON certificate.')

    plain = {}
    ell = None
    weights = []
    for line in (ROOT/'tau_sos_polynomials.txt').read_text().splitlines():
        heading = re.fullmatch(r'q(\d+), weight (\d+):', line)
        if heading:
            ell = int(heading[1])
            weights.append(s.Rational(heading[2]))
        elif re.match(r'\s+w\d\d:', line):
            name, expression = line.strip().split(':', 1)
            key = ell, name[1:]
            assert key not in plain and key in expected
            plain[key] = s.sympify(expression, locals=NAMES)
    assert weights == [1]*8+[2]*2
    for key in expected:
        assert s.expand(plain.get(key, s.S.Zero)-expected[key]) == 0
    print('PASS: the plain-text coefficient file agrees, including omitted zero entries.')


def check_similarity_diagonal() -> None:
    # A fully general, potentially nonsymmetric diagonalizer. Clearing det(T)
    # avoids rational simplification and tests the direction of the identity.
    T = s.Matrix(3, 3, s.symbols('t0:9'))
    lam = s.Matrix(s.symbols('l0:3'))
    adj = T.adjugate()
    transformed = T*s.diag(*lam)*adj
    lhs = s.Matrix([transformed[i, i] for i in range(3)])
    rhs = T.multiply_elementwise(adj.T)*lam
    assert all(s.expand(q) == 0 for q in lhs-rhs)
    print('PASS: general similarity identity diag(T*D*T^-1) = (T o T^-T)*lambda.')


def check_energy_and_degenerate_components() -> None:
    a,b,c,d,e,f = VARIABLES
    L = s.Matrix([[1,0,0,0],[a,1,0,0],[b,c,1,0],[d,e,f,1]])
    G = L*L.T
    Li = L.inv()
    Gi = Li.T*Li
    K = G.multiply_elementwise(Gi)
    x = s.Matrix(s.symbols('x0:4'))
    D = s.diag(*x)
    commutator = G*D-D*G
    # This is the squared commutator norm with square roots eliminated.
    energy = (x.T*(K-s.eye(4))*x)[0]
    norm_squared = -s.trace(Gi*commutator*Gi*commutator)
    assert s.expand(2*energy-norm_squared) == 0
    print('PASS: interaction-energy identity as a polynomial identity on a general four-block.')

    # Disconnected and diagonal cases check the equality-space and rho=0 edges.
    G = s.diag(s.Matrix([[2,1],[1,2]]), s.Matrix([[3,-1],[-1,2]]), s.Matrix([[7]]))
    K = G.multiply_elementwise(G.inv())
    R = K.inv()
    Pi = s.diag(s.ones(2)/2, s.ones(2)/2, s.ones(1))
    assert R*Pi == Pi and Pi*R == Pi
    assert (K-s.eye(5)).rank() == (s.eye(5)-R).rank() == 2
    assert all(v > 0 and v <= 1 for v in R.eigenvals())
    assert all(abs(v) < 1 for v in (R-Pi).eigenvals())
    for H in (s.eye(1), s.diag(2,3,7)):
        assert H.multiply_elementwise(H.inv()).inv() == s.eye(H.rows)
    print('PASS: exact disconnected-component, singleton, and diagonal boundary cases.')


def check_full_counterexample() -> None:
    G = s.Matrix([[21,3],[3,21]]).row_join(s.ones(2,5)*4).col_join(
        (4*s.ones(5,2)).row_join(16*s.eye(5)))
    S = G[:2,:2]-G[:2,2:]*(16*s.eye(5)).inv()*G[2:,:2]
    assert S == s.Matrix([[16,-2],[-2,16]])
    assert S[0,0] > 0 and S.det() > 0
    K = G.multiply_elementwise(G.inv())
    expected_K = s.Matrix([[s.Rational(4,3),s.Rational(1,42)],
                           [s.Rational(1,42),s.Rational(4,3)]]).row_join(-s.ones(2,5)/14).col_join(
        (-s.ones(5,2)/14).row_join(s.Rational(8,7)*s.eye(5)))
    assert K == expected_K
    H = K[:2,:2]-K[:2,2:]*K[2:,2:].inv()*K[2:,:2]
    assert H == s.Matrix([[881,1],[1,881]])/672
    R = K.inv()
    assert R[:2,:2] == H.inv()
    assert R[0,1] == -s.Rational(1,1155)
    lam = s.Matrix([-1,881,55,55,55,55,55])/1155
    assert lam == R[:,1]
    B = G*s.diag(*lam)*G.inv()
    assert s.Matrix([B[i,i] for i in range(7)]) == s.eye(7)[:,1]
    assert sum(sorted(lam, reverse=True)[:6]) == s.Rational(1156,1155)
    assert sum(lam) == 1
    print('PASS: full G7, K7, Schur complement, inverse column, and reverse-majorization violation.')


def main() -> None:
    check_printed_coefficients()
    check_similarity_diagonal()
    check_energy_and_degenerate_components()
    check_full_counterexample()


if __name__ == '__main__':
    main()
