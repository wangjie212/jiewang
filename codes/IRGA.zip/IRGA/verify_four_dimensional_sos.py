#!/usr/bin/env python3
"""Verify the four-dimensional exterior-square SOS using exact arithmetic.

Requires Python 3.10+ and SymPy. No numerical solver or stored pickle is used.
Run beside tau_sos_polynomials.json:
    python verify_four_dimensional_sos.py

The certificate proves E + tau*J is positive semidefinite for C = L L^T,
where L is a general 4 x 4 unit lower-triangular matrix. The formula for E
is stated in the accompanying proof notes. Diagonal congruence then gives
all real symmetric positive-definite C of order four.
"""
from __future__ import annotations
import json
from itertools import combinations, permutations
from pathlib import Path
import time
import sympy as s

if not __debug__:
    raise RuntimeError('Run without -O: this verifier uses assertions.')


def main() -> None:
    start = time.monotonic()
    data = json.loads(Path(__file__).with_name('tau_sos_polynomials.json').read_text())
    variables = s.symbols('a b c d e f')
    a, b, c, d, e, f = variables
    wedges = s.symbols('w12 w13 w14 w23 w24 w34')
    names = {str(x): x for x in (*variables, *wedges)}
    assert data['variables'] == [str(x) for x in variables]
    assert data['wedge_variables'] == [str(x) for x in wedges]
    assert [s.Rational(entry['weight']) for entry in data['squares']] == [1]*8+[2]*2
    poly = lambda expression: s.Poly(expression, *variables, domain=s.QQ)
    zero = poly(0)
    L = s.Matrix([[1,0,0,0], [a,1,0,0], [b,c,1,0], [d,e,f,1]])
    Linv = L.inv()
    C = L * L.T
    Cinv = Linv.T * Linv
    K = C.multiply_elementwise(Cinv)
    Cp = [[poly(C[i,j]) for j in range(4)] for i in range(4)]
    Kp = [[poly(K[i,j]) for j in range(4)] for i in range(4)]

    def determinant(matrix):
        n = len(matrix)
        result = zero
        for permutation in permutations(range(n)):
            inversions = sum(permutation[i] > permutation[j]
                             for i in range(n) for j in range(i+1,n))
            term = poly((-1)**inversions)
            for i, j in enumerate(permutation):
                term *= matrix[i][j]
            result += term
        return result

    # Adj = det(K) K^{-1}, constructed by cofactors, not matrix inversion.
    Adj = [[(-1)**(i+j) * determinant([
        [Kp[k][ell] for ell in range(4) if ell != i]
        for k in range(4) if k != j]) for j in range(4)] for i in range(4)]
    detK = determinant(Kp)
    for i in range(4):
        for j in range(4):
            assert sum((Kp[i][k]*Adj[k][j] for k in range(4)), zero) == (detK if i == j else zero)
    print('PASS: polynomial adjugate satisfies K*adj(K) = det(K)*I.')
    X, Y, Z = Cp[0][1]*Cp[2][3], Cp[0][2]*Cp[1][3], Cp[0][3]*Cp[1][2]
    A, B, D = Adj[0][1]+Adj[2][3], Adj[0][2]+Adj[1][3], Adj[0][3]+Adj[1][2]
    tau_scaled = X*(D-B) + Y*(A-D) + Z*(B-A)
    pairs = list(combinations(range(4), 2))
    J = s.zeros(6)
    J[0,5] = J[5,0] = 1
    J[1,4] = J[4,1] = -1
    J[2,3] = J[3,2] = 1
    # T = 4 det(K) (E + tau J).
    T = [[
        Cp[i][k]*Cp[j][ell]*(Adj[i][j]+Adj[i][ell]+Adj[k][j]+Adj[k][ell])
        - Cp[i][ell]*Cp[j][k]*(Adj[i][j]+Adj[i][k]+Adj[ell][j]+Adj[ell][k])
        + int(J[h,g])*tau_scaled
        for g, (k,ell) in enumerate(pairs)]
        for h, (i,j) in enumerate(pairs)]
    # Exterior square of L^{-1} and its congruence action.
    B2 = [[poly(Linv[i,k]*Linv[j,ell]-Linv[i,ell]*Linv[j,k])
           for k,ell in pairs] for i,j in pairs]
    BT = [[sum((B2[i][k]*T[k][j] for k in range(6)), zero)
           for j in range(6)] for i in range(6)]
    W = [[sum((BT[i][k]*B2[j][k] for k in range(6)), zero)
          for j in range(6)] for i in range(6)]

    gram = [[zero for _ in range(6)] for _ in range(6)]
    for entry in data['squares']:
        weight = s.Rational(entry['weight'])
        assert weight > 0
        expression = s.sympify(entry['polynomial'], locals=names)
        coefficients = [poly(s.diff(expression, w)) for w in wedges]
        assert s.expand(expression-sum(w*p.as_expr() for w,p in zip(wedges,coefficients))) == 0
        for i in range(6):
            for j in range(6):
                gram[i][j] += weight * coefficients[i]*coefficients[j]

    checked = 0
    for i in range(6):
        for j in range(6):
            assert T[i][j] == T[j][i]
            assert W[i][j] == W[j][i]
            difference = W[i][j] - gram[i][j]
            if not difference.is_zero:
                raise AssertionError(f'Certificate fails at entry {(i+1,j+1)}: {difference.as_expr()}')
            checked += 1
    print(f'PASS: all {checked} polynomial matrix entries agree exactly over Q.')
    print(f'PASS: {len(data["squares"])} squares, all with strictly positive rational weights.')
    print(f'Elapsed: {time.monotonic()-start:.2f} seconds.')


if __name__ == '__main__':
    main()
