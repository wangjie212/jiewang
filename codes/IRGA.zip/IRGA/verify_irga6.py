#!/usr/bin/env python3
"""Exact checks accompanying the real symmetric six-dimensional IRGA proof.

The universal nonnegativity certificate is checked polynomially over Q.
Bordering identities are proved in the accompanying notes. This script also
checks their algebra independently, and tests illustrative matrices exactly.
Requires Python 3.10+ and SymPy; no numerical solver is used.
"""
from __future__ import annotations
from itertools import combinations
from pathlib import Path
import importlib.util
import random
import sympy as s

if not __debug__:
    raise RuntimeError('Run without -O: this verifier uses assertions.')


def diagonal(v: s.Matrix) -> s.Matrix:
    return s.diag(*v)


def matrix_diagonal(M: s.Matrix) -> s.Matrix:
    return s.Matrix([M[i, i] for i in range(M.rows)])


def symmetric(M: s.Matrix) -> s.Matrix:
    return (M + M.T) / 2


def d(C: s.Matrix, x: s.Matrix) -> s.Matrix:
    return diagonal(x) * C * x


def normalized_border(C: s.Matrix, x: s.Matrix) -> s.Matrix:
    return s.Matrix([[1 + (x.T * C * x)[0]]]).row_join(x.T * C).col_join(
        (C * x).row_join(C)
    )


def run_certificate() -> None:
    filename = Path(__file__).with_name('verify_four_dimensional_sos.py')
    spec = importlib.util.spec_from_file_location('irga4_certificate', filename)
    if spec is None or spec.loader is None:
        raise RuntimeError('Cannot load the certificate verifier')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.main()


def check_exterior_identity() -> None:
    """Universal identity, with C and R independently symmetric indeterminates."""
    n = 4
    C, R = s.zeros(n), s.zeros(n)
    for i in range(n):
        for j in range(i, n):
            C[i, j] = C[j, i] = s.Symbol(f'c{i}{j}')
            R[i, j] = R[j, i] = s.Symbol(f'r{i}{j}')
    x, y = s.Matrix(s.symbols('x0:4')), s.Matrix(s.symbols('y0:4'))
    pairs = list(combinations(range(n), 2))
    wedge = s.Matrix([x[i]*y[j]-x[j]*y[i] for i,j in pairs])
    E = s.zeros(6)
    for a, (i,j) in enumerate(pairs):
        for b, (k,l) in enumerate(pairs):
            E[a,b] = (C[i,k]*C[j,l]*(R[i,j]+R[i,l]+R[k,j]+R[k,l])
                      - C[i,l]*C[j,k]*(R[i,j]+R[i,k]+R[l,j]+R[l,k]))/4
    h = (diagonal(x)*C*y+diagonal(y)*C*x)/2
    expression = (d(C,x).T*R*d(C,y)-h.T*R*h-wedge.T*E*wedge)[0]
    assert s.expand(expression) == 0
    print('PASS: exterior-square identity as a universal polynomial identity.')


def check_border_quadratic_identity() -> None:
    """Universal identity, with arbitrary symmetric C and arbitrary t."""
    n = 4
    C = s.zeros(n)
    for i in range(n):
        for j in range(i,n):
            C[i,j] = C[j,i] = s.Symbol(f'C{i}{j}')
    x = s.Matrix(s.symbols('x0:4'))
    t = s.Matrix(s.symbols('t0:4'))
    z = s.Matrix(s.symbols('z0:4'))
    a = s.Symbol('a')
    one = s.ones(n,1)
    b = one-t
    A = normalized_border(C,x)
    w = s.Matrix([a]).col_join(z)
    y = z+a*x
    v = C*diagonal(x)*b
    S = symmetric(diagonal(t)*C)
    lhs = (s.Matrix([[1]]).row_join(t.T)*d(A,w))[0]
    rhs = a*a+a*(v.T*y)[0]+(y.T*S*y)[0]
    assert s.expand(lhs-rhs) == 0
    print('PASS: bordering quadratic identity as a universal polynomial identity.')


def check_residual_identity() -> None:
    """Universal residual identity on a general unit-Cholesky four-block."""
    a,b,c,dd,e,f=s.symbols('a b c dd e f')
    L=s.Matrix([[1,0,0,0],[a,1,0,0],[b,c,1,0],[dd,e,f,1]])
    C=L*L.T
    Ci=L.inv().T*L.inv()
    K=C.multiply_elementwise(Ci)
    x=s.Matrix(s.symbols('x0:4'))
    beta=s.Matrix(s.symbols('b0:4'))
    t=s.ones(4,1)-beta
    N=K+diagonal(x)*C*diagonal(x)
    z=diagonal(x)*beta
    X=z*z.T+diagonal(t)*Ci*diagonal(t)
    residual=matrix_diagonal(C*X)-K*t-diagonal(beta)*(N*beta-s.ones(4,1))
    assert all(s.expand(q)==0 for q in residual)
    print('PASS: finite-coupling PSD residual identity universally on a four-block.')


def check_exact_examples() -> None:
    rng=random.Random(609062026)
    for n in (4,5,6):
        for sample in range(4):
            L=s.eye(n)
            for i in range(n):
                for j in range(i):
                    L[i,j]=s.Rational(rng.randint(-3,3),rng.randint(1,3))
            G=L*L.T
            H=G.multiply_elementwise(G.inv())
            R=H.inv()
            assert all(q>=0 for q in R)
            if n==5:
                # Verify the claimed stronger quadratic positivity by all
                # principal minors, not by floating-point eigenvalues.
                for i in range(n):
                    B=symmetric(diagonal(R[:,i])*G)
                    for k in range(1,n+1):
                        for I in combinations(range(n),k):
                            assert B.extract(I,I).det()>=0
            C=G[1:,1:]
            c=G[1:,0]
            schur=G[0,0]-(c.T*C.inv()*c)[0]
            # These unit-Cholesky examples need not have square Schur roots;
            # use a separately constructed rational normalized border instead.
            x=s.Matrix([s.Rational(rng.randint(-3,3),3) for _ in range(n-1)])
            A=normalized_border(C,x)
            K=C.multiply_elementwise(C.inv())
            N=K+diagonal(x)*C*diagonal(x)
            b=N.inv()*s.ones(n-1,1)
            t=s.ones(n-1,1)-b
            sigma=1+sum(t)
            RA=A.multiply_elementwise(A.inv()).inv()
            assert RA[0,:]==s.Matrix([[1]]).row_join(t.T)/sigma
            z=diagonal(x)*b
            X=z*z.T+diagonal(t)*C.inv()*diagonal(t)
            assert matrix_diagonal(C*X)==K*t
            if n==5:
                RC=K.inv()
                Phi=lambda X:symmetric(diagonal(RC*matrix_diagonal(C*X))*C)
                Q=symmetric(diagonal(t)*C)-C*z*z.T*C/4
                rhs=Phi(z*z.T)-C*z*z.T*C/4+Phi(diagonal(t)*C.inv()*diagonal(t))
                assert Q==rhs
    print('PASS: exact bordering and positivity checks in orders four, five, and six.')
    # Existing seven-dimensional counterexample is compatible with the cutoff.
    one=s.ones(5,1)
    G7=s.Matrix([[21,3],[3,21]]).row_join(s.Matrix.vstack(4*one.T,4*one.T)).col_join(
        s.Matrix.hstack(4*one,4*one,16*s.eye(5)))
    R7=G7.multiply_elementwise(G7.inv()).inv()
    assert R7[0,1]==-s.Rational(1,1155)
    print('PASS: order-seven check = -1/1155, so no unintended all-dimension claim.')


def main() -> None:
    print(f'Exact verification using SymPy {s.__version__}.')
    run_certificate()
    check_exterior_identity()
    check_border_quadratic_identity()
    check_residual_identity()
    check_exact_examples()
    filename = Path(__file__).with_name('verify_manuscript.py')
    spec = importlib.util.spec_from_file_location('irga_manuscript', filename)
    if spec is None or spec.loader is None:
        raise RuntimeError('Cannot load the manuscript verifier')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.main()
    print('ALL CHECKS PASSED. The dimension-independent arguments are proved in the manuscript.')


if __name__=='__main__':
    main()
