#!/usr/bin/env python3
"""Independent exact checker: runs on its own with paper_thm3_data.json.
No imports from another local .py module. Requires NetworkX/SymPy as applicable.
All reported comparisons are exact.
"""
from __future__ import annotations
import json
import re
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from pathlib import Path

R = Fraction
DATA = json.loads(Path(__file__).with_name('paper_thm3_data.json').read_text(encoding='utf-8'))
EDGES = [tuple(edge) for edge in DATA['edges']]
EDGE_IDS = {edge: k + 13 for k, edge in enumerate(EDGES)}
LAMBDA = R(*DATA['lambda'])
GRAM_DENOMINATOR = 200_000_000
EPSILON = R(1, 10**12)
DELTA = R(1, 10**8)
QUADRATICS = list(combinations_with_replacement(range(43), 2))
QUADRATIC_INDEX = {mon: k for k, mon in enumerate(QUADRATICS)}


def ensure(test: bool, what: str) -> None:
    if not test:
        raise AssertionError(what)

def decode_variable(token: str) -> int:
    if token == 't':
        return 0
    if token.startswith('x_'):
        return int(token[2:])
    if token.startswith('y_{'):
        s = token[3:-1]
        if ',' in s:
            a, b = map(int, s.split(','))
        else:
            ensure(len(s) == 2, f'Ambiguous graph edge in {token}')
            a, b = map(int, s)
        return EDGE_IDS[tuple(sorted((a, b)))]
    raise ValueError(f'Unknown variable: {token}')

def parse_quadratic(s: str) -> tuple[int, int]:
    tokens = re.findall(r't|x_\d+|y_\{[\d,]+\}', s)
    output = []
    pos = 0
    for token in tokens:
        ensure(s.startswith(token, pos), f'Unexpected quadratic notation: {s}')
        pos += len(token)
        exponent = 2 if s.startswith('^2', pos) else 1
        if exponent == 2:
            pos += 2
        output.extend([decode_variable(token)] * exponent)
    ensure(pos == len(s) and len(output) == 2, f'Not a quadratic monomial: {s}')
    return tuple(sorted(output))

def build_gram():
    """Reconstruct paper's 564 rational Gram blocks from 51 orbit entries.

    Returns (values, blocks) where values maps pairs of quadratic-basis indices
    to Fraction entries and blocks are integral matrices 200000000 * G_F|block.
    """
    import networkx as nx

    graph = nx.Graph()
    graph.add_nodes_from(range(1, 13))
    graph.add_edges_from(EDGES)
    perms = []
    for auto in nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter():
        p = [0] + [auto[i] for i in range(1, 13)]
        p += [EDGE_IDS[tuple(sorted((auto[i], auto[j])))] for i, j in EDGES]
        perms.append(p)
    ensure(len(perms) == 120, 'Expected 120 automorphisms of the icosahedral graph')

    sign_char = [1] + [1 << i for i in range(1, 13)]
    sign_char += [1 | (1 << i) | (1 << j) for i, j in EDGES]
    character_blocks = defaultdict(list)
    for j, (a, b) in enumerate(QUADRATICS):
        character_blocks[sign_char[a] ^ sign_char[b]].append(j)
    allowed = {(min(i, j), max(i, j))
               for block in character_blocks.values() for i in block for j in block}
    ensure(len(allowed) == 2449, 'Incorrect number of same-character Gram entries')

    image = [
        [QUADRATIC_INDEX[tuple(sorted((p[a], p[b])))] for a, b in QUADRATICS]
        for p in perms
    ]
    values: dict[tuple[int, int], Fraction] = {}
    for row, (mu, nu, rational) in enumerate(DATA['table']):
        a = QUADRATIC_INDEX[parse_quadratic(mu)]
        b = QUADRATIC_INDEX[parse_quadratic(nu)]
        orbit = {(min(p[a], p[b]), max(p[a], p[b])) for p in image}
        ensure(orbit <= allowed and not (orbit & values.keys()),
               f'Bad/overlapping Gram orbit at Appendix A.1 row {row}')
        coefficient = R(rational)
        for pair in orbit:
            values[pair] = coefficient
    ensure(len(DATA['table']) == 51 and set(values) == allowed,
           'The 51 orbit coefficients do not cover the Gram matrix')

    indices = list(character_blocks.values())
    ensure(len(indices) == 564 and sum(map(len, indices)) == 946,
           'Incorrect character block partition')
    matrices = []
    for block in indices:
        M = []
        for i in block:
            row = []
            for j in block:
                entry = GRAM_DENOMINATOR * values[(min(i, j), max(i, j))]
                ensure(entry.denominator == 1, 'Gram scaling is not integral')
                row.append(int(entry))
            M.append(row)
        matrices.append(M)
    return values, matrices

def gram_target_coefficients() -> dict[tuple[int, ...], Fraction]:
    """Coefficients of F=t^4+3Q^2-18 lambda t*g, with Q=sum z_i^2."""
    target = defaultdict(R)
    target[(0,0,0,0)] = R(1)
    for i in range(1,43):
        target[(i,i,i,i)] += 3
        for j in range(i+1,43):
            target[(i,i,j,j)] += 6
    for i,j in EDGES:
        target[tuple(sorted((0,i,j,EDGE_IDS[(i,j)])))] -= 18*LAMBDA
    return {m:v for m,v in target.items() if v}

def add_term(out: dict, mon: tuple[int, ...], coefficient: Fraction) -> None:
    if coefficient == 0:
        return
    key = tuple(sorted(mon))
    out[key] += coefficient
    if out[key] == 0:
        del out[key]

def check_prop51_gram_identity():
    """One claim: the Appendix A.1 Gram entries represent F exactly."""
    values, _ = build_gram()
    actual = defaultdict(R)
    for (i,j),entry in values.items():
        add_term(actual, QUADRATICS[i] + QUADRATICS[j],
                 entry*(1 if i==j else 2))
    ensure(dict(actual) == gram_target_coefficients(),
           'Proposition 5.1: m_2^T G_F m_2 != F')
    print('[PASS P5.1 / Gram identity] 51 orbits, 2449 pairs, F=m2^T G_F m2, exact')

if __name__ == "__main__":
    check_prop51_gram_identity()
