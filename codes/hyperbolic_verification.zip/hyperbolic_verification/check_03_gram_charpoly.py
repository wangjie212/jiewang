#!/usr/bin/env python3
"""Independent exact checker: runs on its own with paper_thm3_data.json.
No imports from another local .py module. Requires NetworkX/SymPy as applicable.
All reported comparisons are exact.
"""
from __future__ import annotations
import json
import re
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from pathlib import Path

R = Fraction
DATA = json.loads(Path(__file__).with_name('paper_thm3_data.json').read_text(encoding='utf-8'))
EDGES = [tuple(edge) for edge in DATA['edges']]
EDGE_IDS = {edge: k + 13 for k, edge in enumerate(EDGES)}
LAMBDA = R(*DATA['lambda'])
GRAM_DENOMINATOR = 200_000_000
EPSILON = R(1, 10**12)
DELTA = R(1, 10**8)
QUADRATICS = list(combinations_with_replacement(range(43), 2))
QUADRATIC_INDEX = {mon: k for k, mon in enumerate(QUADRATICS)}


def ensure(test: bool, what: str) -> None:
    if not test:
        raise AssertionError(what)

def decode_variable(token: str) -> int:
    if token == 't':
        return 0
    if token.startswith('x_'):
        return int(token[2:])
    if token.startswith('y_{'):
        s = token[3:-1]
        if ',' in s:
            a, b = map(int, s.split(','))
        else:
            ensure(len(s) == 2, f'Ambiguous graph edge in {token}')
            a, b = map(int, s)
        return EDGE_IDS[tuple(sorted((a, b)))]
    raise ValueError(f'Unknown variable: {token}')

def parse_quadratic(s: str) -> tuple[int, int]:
    tokens = re.findall(r't|x_\d+|y_\{[\d,]+\}', s)
    output = []
    pos = 0
    for token in tokens:
        ensure(s.startswith(token, pos), f'Unexpected quadratic notation: {s}')
        pos += len(token)
        exponent = 2 if s.startswith('^2', pos) else 1
        if exponent == 2:
            pos += 2
        output.extend([decode_variable(token)] * exponent)
    ensure(pos == len(s) and len(output) == 2, f'Not a quadratic monomial: {s}')
    return tuple(sorted(output))

def build_gram():
    """Reconstruct paper's 564 rational Gram blocks from 51 orbit entries.

    Returns (values, blocks) where values maps pairs of quadratic-basis indices
    to Fraction entries and blocks are integral matrices 200000000 * G_F|block.
    """
    import networkx as nx

    graph = nx.Graph()
    graph.add_nodes_from(range(1, 13))
    graph.add_edges_from(EDGES)
    perms = []
    for auto in nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter():
        p = [0] + [auto[i] for i in range(1, 13)]
        p += [EDGE_IDS[tuple(sorted((auto[i], auto[j])))] for i, j in EDGES]
        perms.append(p)
    ensure(len(perms) == 120, 'Expected 120 automorphisms of the icosahedral graph')

    sign_char = [1] + [1 << i for i in range(1, 13)]
    sign_char += [1 | (1 << i) | (1 << j) for i, j in EDGES]
    character_blocks = defaultdict(list)
    for j, (a, b) in enumerate(QUADRATICS):
        character_blocks[sign_char[a] ^ sign_char[b]].append(j)
    allowed = {(min(i, j), max(i, j))
               for block in character_blocks.values() for i in block for j in block}
    ensure(len(allowed) == 2449, 'Incorrect number of same-character Gram entries')

    image = [
        [QUADRATIC_INDEX[tuple(sorted((p[a], p[b])))] for a, b in QUADRATICS]
        for p in perms
    ]
    values: dict[tuple[int, int], Fraction] = {}
    for row, (mu, nu, rational) in enumerate(DATA['table']):
        a = QUADRATIC_INDEX[parse_quadratic(mu)]
        b = QUADRATIC_INDEX[parse_quadratic(nu)]
        orbit = {(min(p[a], p[b]), max(p[a], p[b])) for p in image}
        ensure(orbit <= allowed and not (orbit & values.keys()),
               f'Bad/overlapping Gram orbit at Appendix A.1 row {row}')
        coefficient = R(rational)
        for pair in orbit:
            values[pair] = coefficient
    ensure(len(DATA['table']) == 51 and set(values) == allowed,
           'The 51 orbit coefficients do not cover the Gram matrix')

    indices = list(character_blocks.values())
    ensure(len(indices) == 564 and sum(map(len, indices)) == 946,
           'Incorrect character block partition')
    matrices = []
    for block in indices:
        M = []
        for i in block:
            row = []
            for j in block:
                entry = GRAM_DENOMINATOR * values[(min(i, j), max(i, j))]
                ensure(entry.denominator == 1, 'Gram scaling is not integral')
                row.append(int(entry))
            M.append(row)
        matrices.append(M)
    return values, matrices

def gram_type_specifications(X):
    """(multiplicity, dimension, integer scale, characteristic polynomial): Appendix A.2."""
    return [
      (1,43,200000000,(X-854270790)**5*(X-509460)**4*(X-49542)**4
       *(X**3-5241027569*X**2+305503575098265068*X-18813190163221355560)
       *(X**3-2547715335*X**2+632310126777944156*X-4342386569824759941684)**5
       *(X**4-1048935266*X**3+237398030060911143*X**2-59037556334482284251102*X+112394644170406114092376124)**3),
      (12,6,100000000,(X**2-3469007884*X+27027333808)*(X**2-134176*X+1131451339)**2),
      (30,4,100000000,(X-55486)*(X**3-1621338663*X**2+152513996875699174*X-198879174346605309264)),
      (30,3,100000000,(X-916831620)*(X**2-628904646*X+22143713201886)),
      (6,1,25000000,X-28989379),
      (60,1,50000000,X-277703341),
      (60,2,100000000,(X-855146351)*(X-53035)),
      (15,1,25000000,X-112043547),
      (60,1,25000000,X-187424861),
      (60,1,50000000,X-334885833),
      (60,1,50000000,X-249137789),
      (60,1,390625,X-2125004),
      (20,3,50000000,(X-451659109)**2*(X-3013)),
      (30,2,100000000,(X-846456376)*(X-106030)),
      (60,1,10000000,X-77665897),
    ]

def check_appendix_A2_charpoly():
    """One claim: all 15 published scaled Gram characteristic-polynomial types."""
    import sympy as sp
    _, blocks = build_gram()
    X = sp.symbols('X')
    classes = {}
    for M in blocks:
        matrix = sp.Matrix(M)
        charpoly = sp.Poly(matrix.charpoly(X).as_expr(), X)
        key = (len(M), tuple(charpoly.all_coeffs()))
        if key not in classes:
            classes[key] = [matrix, 0]
        classes[key][1] += 1
    ensure(len(classes) == 15, f'Expected 15 distinct Gram types, found {len(classes)}')
    matched = set()
    for typ,(count,dim,scale,formula) in enumerate(gram_type_specifications(X)):
        target = sp.Poly(formula,X)
        keys = []
        for key,(matrix,multiplicity) in classes.items():
            if key in matched or multiplicity != count or matrix.rows != dim:
                continue
            actual = sp.Poly((matrix*sp.Rational(scale,GRAM_DENOMINATOR)).charpoly(X).as_expr(),X)
            if actual == target:
                keys.append(key)
        ensure(len(keys) == 1, f'Appendix A.2 type {typ} disagrees with manuscript')
        matched.add(keys[0])
    ensure(len(matched) == len(classes), 'Some Gram type is not covered')
    print('[PASS Appendix A.2] 15 scaled characteristic polynomials, multiplicities, exact')

if __name__ == "__main__":
    check_appendix_A2_charpoly()
