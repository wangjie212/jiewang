#!/usr/bin/env python3
"""Independent exact checker: runs on its own with paper_thm3_data.json.
No imports from another local .py module. Requires NetworkX/SymPy as applicable.
All reported comparisons are exact.
"""
from __future__ import annotations
import json
import re
from collections import defaultdict
from fractions import Fraction
from itertools import combinations, combinations_with_replacement
from pathlib import Path

R = Fraction
DATA = json.loads(Path(__file__).with_name('paper_thm3_data.json').read_text(encoding='utf-8'))
EDGES = [tuple(edge) for edge in DATA['edges']]
EDGE_IDS = {edge: k + 13 for k, edge in enumerate(EDGES)}
LAMBDA = R(*DATA['lambda'])
GRAM_DENOMINATOR = 200_000_000
EPSILON = R(1, 10**12)
DELTA = R(1, 10**8)
QUADRATICS = list(combinations_with_replacement(range(43), 2))
QUADRATIC_INDEX = {mon: k for k, mon in enumerate(QUADRATICS)}


def ensure(test: bool, what: str) -> None:
    if not test:
        raise AssertionError(what)

def decode_variable(token: str) -> int:
    if token == 't':
        return 0
    if token.startswith('x_'):
        return int(token[2:])
    if token.startswith('y_{'):
        s = token[3:-1]
        if ',' in s:
            a, b = map(int, s.split(','))
        else:
            ensure(len(s) == 2, f'Ambiguous graph edge in {token}')
            a, b = map(int, s)
        return EDGE_IDS[tuple(sorted((a, b)))]
    raise ValueError(f'Unknown variable: {token}')

def parse_quadratic(s: str) -> tuple[int, int]:
    tokens = re.findall(r't|x_\d+|y_\{[\d,]+\}', s)
    output = []
    pos = 0
    for token in tokens:
        ensure(s.startswith(token, pos), f'Unexpected quadratic notation: {s}')
        pos += len(token)
        exponent = 2 if s.startswith('^2', pos) else 1
        if exponent == 2:
            pos += 2
        output.extend([decode_variable(token)] * exponent)
    ensure(pos == len(s) and len(output) == 2, f'Not a quadratic monomial: {s}')
    return tuple(sorted(output))

def build_gram():
    """Reconstruct paper's 564 rational Gram blocks from 51 orbit entries.

    Returns (values, blocks) where values maps pairs of quadratic-basis indices
    to Fraction entries and blocks are integral matrices 200000000 * G_F|block.
    """
    import networkx as nx

    graph = nx.Graph()
    graph.add_nodes_from(range(1, 13))
    graph.add_edges_from(EDGES)
    perms = []
    for auto in nx.algorithms.isomorphism.GraphMatcher(graph, graph).isomorphisms_iter():
        p = [0] + [auto[i] for i in range(1, 13)]
        p += [EDGE_IDS[tuple(sorted((auto[i], auto[j])))] for i, j in EDGES]
        perms.append(p)
    ensure(len(perms) == 120, 'Expected 120 automorphisms of the icosahedral graph')

    sign_char = [1] + [1 << i for i in range(1, 13)]
    sign_char += [1 | (1 << i) | (1 << j) for i, j in EDGES]
    character_blocks = defaultdict(list)
    for j, (a, b) in enumerate(QUADRATICS):
        character_blocks[sign_char[a] ^ sign_char[b]].append(j)
    allowed = {(min(i, j), max(i, j))
               for block in character_blocks.values() for i in block for j in block}
    ensure(len(allowed) == 2449, 'Incorrect number of same-character Gram entries')

    image = [
        [QUADRATIC_INDEX[tuple(sorted((p[a], p[b])))] for a, b in QUADRATICS]
        for p in perms
    ]
    values: dict[tuple[int, int], Fraction] = {}
    for row, (mu, nu, rational) in enumerate(DATA['table']):
        a = QUADRATIC_INDEX[parse_quadratic(mu)]
        b = QUADRATIC_INDEX[parse_quadratic(nu)]
        orbit = {(min(p[a], p[b]), max(p[a], p[b])) for p in image}
        ensure(orbit <= allowed and not (orbit & values.keys()),
               f'Bad/overlapping Gram orbit at Appendix A.1 row {row}')
        coefficient = R(rational)
        for pair in orbit:
            values[pair] = coefficient
    ensure(len(DATA['table']) == 51 and set(values) == allowed,
           'The 51 orbit coefficients do not cover the Gram matrix')

    indices = list(character_blocks.values())
    ensure(len(indices) == 564 and sum(map(len, indices)) == 946,
           'Incorrect character block partition')
    matrices = []
    for block in indices:
        M = []
        for i in block:
            row = []
            for j in block:
                entry = GRAM_DENOMINATOR * values[(min(i, j), max(i, j))]
                ensure(entry.denominator == 1, 'Gram scaling is not integral')
                row.append(int(entry))
            M.append(row)
        matrices.append(M)
    return values, matrices

def integer_positive_definite(matrix: list[list[int]]):
    """Sylvester criterion via exact integer Bareiss elimination."""
    n = len(matrix)
    ensure(n > 0 and all(len(row) == n for row in matrix), 'Matrix not square')
    ensure(all(matrix[i][j] == matrix[j][i] for i in range(n) for j in range(i)),
           'Matrix not symmetric')
    a = [row[:] for row in matrix]
    previous = 1
    for k in range(n - 1):
        pivot = a[k][k]
        ensure(pivot > 0, f'Leading principal minor of order {k+1} not positive')
        for i in range(k+1, n):
            for j in range(i, n):
                quotient, remainder = divmod(pivot*a[i][j] - a[i][k]*a[k][j], previous)
                ensure(remainder == 0, 'Bareiss quotient is not integral')
                a[i][j] = a[j][i] = quotient
        previous = pivot
    ensure(a[-1][-1] > 0, 'Final leading principal minor not positive')

def check_prop51_gram_positive():
    """One claim: the strict Gram margin G_F - 10^{-8}I_946 is positive."""
    _, blocks = build_gram()
    shift = GRAM_DENOMINATOR*DELTA
    ensure(shift.denominator == 1, 'The positive-definiteness shift is not integral')
    for k,M in enumerate(blocks):
        shifted = [[x-(int(shift) if i==j else 0) for j,x in enumerate(row)]
                   for i,row in enumerate(M)]
        try:
            integer_positive_definite(shifted)
        except AssertionError as exc:
            raise AssertionError(f'Gram block {k} failed: {exc}') from exc
    print('[PASS P5.1 / Gram positivity] all 564 blocks, G_F - 1/100000000 I > 0, exact')

if __name__ == "__main__":
    check_prop51_gram_positive()
