n: the number of varibles
coe_n: the coefficient vector
supp_n: the support vector